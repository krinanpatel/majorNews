//
//  MajorNewsApp.swift
//  MajorNews
//
//  Created by Atif Alam on 4/25/23.
//

import SwiftUI

@main
struct MajorNewsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
