import UIKit
class ViewController: UIViewController {
    
    let favoriteLabel: UILabel = {
        let label = UILabel()
        label.text = "My Favorites"
        label.font = UIFont.boldSystemFont(ofSize: 24)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    let articlesTableView: UITableView = {
        let tableView = UITableView()
        tableView.translatesAutoresizingMaskIntoConstraints = false
        return tableView
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        view.backgroundColor = .white
        
        // Add subviews
        view.addSubview(favoriteLabel)
        view.addSubview(articlesTableView)
        
        // Set up constraints
        NSLayoutConstraint.activate([
            favoriteLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            favoriteLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            
            articlesTableView.topAnchor.constraint(equalTo: favoriteLabel.bottomAnchor, constant: 20),
            articlesTableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            articlesTableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            articlesTableView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor)
        ])
        
        // Set up table view data source and delegate
        articlesTableView.dataSource = self
        articlesTableView.delegate = self
    }
}

extension ViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10 // Replace with actual data source
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: "cell")
        cell.textLabel?.text = "Article \(indexPath.row + 1)" // Replace with actual data source
        return cell
    }
    
}

class SecondViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .blue
        
        let label = UILabel(frame: CGRect(x: 0, y: 0, width: 200, height: 100))
        label.text = "Second View Controller"
        label.textAlignment = .center
        label.font = UIFont.boldSystemFont(ofSize: 24)
        label.center = view.center
        view.addSubview(label)
    }
    
}

class TabBarController: UITabBarController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let firstViewController = ViewController()
        let secondViewController = SecondViewController()
        
        firstViewController.title = "First"
        secondViewController.title = "Second"
        
        viewControllers = [firstViewController, secondViewController]
    }
    
}

let tabBarController = TabBarController()
