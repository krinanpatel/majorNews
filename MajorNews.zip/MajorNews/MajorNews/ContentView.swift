import UIKit
import SwiftUI
import Foundation
struct Article: Identifiable {
    let id = UUID()
    let url: String
    let title: String
    let description: String
}
var favorite_articles = [
    
    Article(url:"google.com", title: "NASA Announces Plans for First Manned Mission to Mars", description: "NASA has announced that it plans to send astronauts to Mars by the year 2030, marking the first time that humans will have set foot on the Red Planet."),
    Article(url:"google.com", title: "Apple Unveils New iPhone 13 with Improved Camera and Battery Life", description: "At its annual September event, Apple announced the release of the iPhone 13, featuring a new A15 Bionic chip, improved camera system, and longer battery life."),
]
/*
let articles = [
    
    Article(title: "NASA Announces Plans for First Manned Mission to Mars", description: "NASA has announced that it plans to send astronauts to Mars by the year 2030, marking the first time that humans will have set foot on the Red Planet."),
    Article(title: "Apple Unveils New iPhone 13 with Improved Camera and Battery Life", description: "At its annual September event, Apple announced the release of the iPhone 13, featuring a new A15 Bionic chip, improved camera system, and longer battery life."),
    Article(title: "NASA Announces Plans for First Manned Mission to Mars", description: "NASA has announced that it plans to send astronauts to Mars by the year 2030, marking the first time that humans will have set foot on the Red Planet."),
    Article(title: "Apple Unveils New iPhone 13 with Improved Camera and Battery Life", description: "At its annual September event, Apple announced the release of the iPhone 13, featuring a new A15 Bionic chip, improved camera system, and longer battery life."),
    Article(title: "NASA Announces Plans for First Manned Mission to Mars", description: "NASA has announced that it plans to send astronauts to Mars by the year 2030, marking the first time that humans will have set foot on the Red Planet."),
    Article(title: "Apple Unveils New iPhone 13 with Improved Camera and Battery Life", description: "At its annual September event, Apple announced the release of the iPhone 13, featuring a new A15 Bionic chip, improved camera system, and longer battery life."),
    Article(title: "NASA Announces Plans for First Manned Mission to Mars", description: "NASA has announced that it plans to send astronauts to Mars by the year 2030, marking the first time that humans will have set foot on the Red Planet."),
    Article(title: "Apple Unveils New iPhone 13 with Improved Camera and Battery Life", description: "At its annual September event, Apple announced the release of the iPhone 13, featuring a new A15 Bionic chip, improved camera system, and longer battery life."),
    Article(title: "NASA Announces Plans for First Manned Mission to Mars", description: "NASA has announced that it plans to send astronauts to Mars by the year 2030, marking the first time that humans will have set foot on the Red Planet."),
    Article(title: "Apple Unveils New iPhone 13 with Improved Camera and Battery Life", description: "At its annual September event, Apple announced the release of the iPhone 13, featuring a new A15 Bionic chip, improved camera system, and longer battery life."),
]*/

struct ContentView: View {
    
    @State private var articles: [Article] = []
    
    @State private var selection = 0
    let majors = ["Computer Science", "Buisness", "Psychology", "Engineering"]
    let name = "John Smith"
    var body: some View {
        TabView {
            // Profile tab
            NavigationView{
                VStack {
                    Image("Image")
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(width: 200, height: 200)
                        .clipShape(Circle())
                        .padding(.top, 50)
                    
                    Text(name)
                        .font(.title)
                        .bold()
                        .padding(.top, 20)
                    HStack{
                        Text("Major:")
                            .font(.headline)
                            .foregroundColor(.gray)
                            .fontWeight(.bold)
                        Picker(selection: $selection, label: Text("Select a major")) {
                            ForEach(0 ..< majors.count) {
                                Text(self.majors[$0]).tag($0)
                            }
                        }
                    }
                    
                    
                }
                .navigationTitle("Profile")
                
            }
            .tabItem {
                Image(systemName: "person.fill")
                Text("Profile")
            }
            
            
            // Feed tab
            
            NavigationView {
                
                List(articles) { article in
                    VStack(alignment: .leading) {
                        Spacer()
                        Text(article.title)
                            .font(.headline)
                        Divider()
                            .background(.red)
                        Text(article.description)
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                        Spacer()
                    }
                }
                .navigationTitle("MajorNews")
                
                .onAppear {
                    if let url = URL(string: "https://majornewsdata-ezaxlyy7pq-uc.a.run.app/get_articles_cnn") {
                        let task = URLSession.shared.dataTask(with: url) { data, response, error in
                            guard let data = data, error == nil else {
                                print("Error: \(error?.localizedDescription ?? "Unknown error")")
                                return
                            }
                            do {
                                    if let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [String: Any],
                                       let cnnString = json["cnn"] as? String,
                                       let cnnData = cnnString.data(using: .utf8),
                                       let cnnJson = try? JSONSerialization.jsonObject(with: cnnData, options: []) as? [String: Any],
                                       let techArray = cnnJson["tech"] as? [[String: Any]] {
                                        
                                        
                                        var tempArticles: [Article] = []
                                        var c = 0
                                        for article in techArray {
                                            if (c%2==0){
                                                let url = article["url"]
                                                let title = article["title"]
                                                let mainText = article["main_text"]
                                               
                                                
                                                
                                                var urlStr = String(describing: url)
                                                var titleStr = String(describing: title)
                                                var descStr = String(describing: mainText)
                                                
                                                titleStr = String(titleStr.dropFirst(15))
                                                titleStr = String(titleStr.dropLast(1))
                                                descStr = String(descStr.dropFirst(9))
                                                descStr = String(descStr.dropLast(1))
                                                if(!titleStr.isEmpty){
                                                    tempArticles.append(Article(url:urlStr,title:titleStr,description:descStr))
                                                }
                                            }
                                            c+=1
                                        }
                                        
                                        DispatchQueue.main.async {
                                            articles = tempArticles
                                        }
                                    }
                                
                            } catch let error {
                                print("Error decoding JSON: \(error.localizedDescription)")
                            }
                        }
                        task.resume()
                    } else {
                        print("Invalid URL")
                    }
                }
            }
            .tabItem {
                Image(systemName: "square.grid.2x2.fill")
                Text("Feed")
            }
     
            
            
            // Favorites tab
            NavigationView {
                List(favorite_articles) { article in
                    HStack {
                        
                        Image(systemName: "heart.fill")
                        
                        Spacer()
                        
                        VStack(alignment: .leading) {
                            Text(article.title)
                                .font(.headline)
                            Text(article.description)
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                        }
                    }
                }
                
                .navigationTitle("Favorites")
                
            }
            .tabItem {
                Image(systemName: "heart.fill")
                Text("Favorites")
            }
           
            
        }
        .accentColor(.red)
    }
   

}

struct NewsPage_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
